import React, { useState, useEffect } from "react";
import ReactDom from "react-dom";
import Text from "./components/text";
import Card from "./components/Card";
import Img from "./images/tf.jpg";
import data from "./data";
import "./components/team.css";
import background from "./images/background.webp";
import MainText from "./main-text"

function App(props) {
  const [currentTab, setCurrentTab] = useState("Core");
  const [currentTeamToShow, setCurrentTeamToShow] = useState(data[0]);

  useEffect(() => {
    const currentTeam = data.filter((team) => team.teamName == currentTab)[0];
    setCurrentTeamToShow(currentTeam);
  }, [currentTab]);

  const style = {
    position: "absolute",
    top: "0",
    left: "0",
    bottom: "0",
    right: "0",
    zIndex: "-1",
    height: "40%",
    width: "100%",
    objectFit: "cover",
    opacity: "0.7",
    linearGradient:"(0deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3))"
  };
 

  return (
    <div
      className="frame "
      style={{
        position: "absolute",
        backgroundColor: "#000",
        top: "0",
        left: "0",
        bottom: "0",
        right: "0",
        zIndex: "-2",
        height: "1350px",
        width: "100%",
        objectFit: "fill",
        linearGradient:"(0deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3))"
      }
      }
    >
      <img style={style} src={background} />
      <Text />
      <div className="team">
        <p onClick={() => setCurrentTab("Core")}>core team</p>
        <p onClick={() => setCurrentTab("Website")}>Website Team</p>
        <p onClick={() => setCurrentTab("Graphix")}>GraphiX Team</p>
        <p onClick={() => setCurrentTab("Marketing")}>Marketing Team</p>
        <p onClick={() => setCurrentTab("Collaborations")}>
          Collaborations Team
        </p>
      </div>

      <MainText
        tab={currentTab}
      />
      
      <div className="main">
        {currentTeamToShow.teamMembers.map((member) => {
          return (
            <Card
              name={member.name}
              img={member.image}
              teamName={currentTab}
              phone={member.phone}
            />
          );
        })}
      </div>
    </div>
  );
}
export default App;
