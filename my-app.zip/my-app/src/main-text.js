import React from "react"; 
import Lhs from "./images/lhs.png";
import Rhs from "./images/rhs.png";
import "./main-text.css";
import data from "./data";

 

 export default function MainText(props){

   

     return(
    <div
    className="mainHeading"
  >
    <img    src={Rhs} className="RHS" />
 <h1  className="main-text" > {props.tab} </h1>
    <img src={Lhs} className="LHS" />
  </div>
     )
}


