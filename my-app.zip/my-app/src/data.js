 import React from "react"
 import Ravi from "./images/ravi.jpg" 
 import pragati from "./images/pragati.jpg" 
 import Tf from "./images/tf.jpg" 
 import Pravin from "./images/pravin.jpg" 
 

 const data = [
    {
        teamName: "Core",
        teamMembers: [
            {
                name: "TechFest22",
                image: Tf,
                phone: 8288912120,
            },
            {
                name: "TechFest22",
                image: Tf,
                phone: 8288912120,
            },
            {
                name: "TechFest22",
                image: Tf,
                phone: 8288912120,
            },
            {
                name: "TechFest22",
                image: Tf,
                phone: 8288912120,
            },
            {
                name: "TechFest22",
                image: Tf,
                phone: 8288912120,
            },
           
        ]
    },

    {
        teamName: "Website",
        teamMembers: [
            {
                name: "Pravin",
                image: Pravin,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
            {
                name: "Pravin",
                image: Pravin,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
            {
                name: "Pravin",
                image: Pravin,
                phone: 8288912120,
            },
           
        ]
    },

    {
        teamName: "Graphix",
        teamMembers: [
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Tf,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Tf,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
           
        ]
    },

    {
        teamName: "Marketing",
        teamMembers: [
            {
                name: "Pragati",
                image: pragati,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
            {
                name: "Pragati",
                image: pragati,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
            {
                name: "Pragati",
                image: pragati,
                phone: 8288912120,
            },
           
        ]
    },
    {
        teamName: "Collaborations",
        teamMembers: [
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Tf,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Tf,
                phone: 8288912120,
            },
            {
                name: "Ravi",
                image: Ravi,
                phone: 8288912120,
            },
           
        ]
    },
]

 export default data;

 