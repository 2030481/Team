import react from "react";
import "./card.css"

export default function card({ name,img, phone, teamName}){

    return(
        <div className="box" >
         <img   className="image"  src={img}/>
         <h3 className="name"  style={{color:"#fff"}} >{ name}</h3>
         <h3 className="teamName"  style={{color:"#fff"}} > {teamName} team member</h3>
         <p className="phone"  style={{color:"#fff"}} > {phone}</p>
        </div>
    )
}