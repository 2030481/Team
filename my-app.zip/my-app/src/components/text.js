import React from "react";
import ReactDom from "react-dom";
import "./text.css"

export default function Text(){
    return(
    
    <div className="text" >
        <h1 className="heading" >
            Our Team
        </h1>
        <p className="paragraph" >
        Together we are making  a difference
        </p>
        </div>
    )
}